# Ensure script is running as Administrator
if (-Not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Host "Please run this script as an Administrator!" -ForegroundColor Red
    exit
}

# Automatically select the latest backup folder
$backupRoot = "C:\GPO_Backups"
$latestFolder = Get-ChildItem -Path $backupRoot -Directory | Sort-Object LastWriteTime -Descending | Select-Object -First 1

if ($null -eq $latestFolder) {
    Write-Host "No backup folders found! Exiting..." -ForegroundColor Red
    exit
}

$backupFolder = $latestFolder.Name
$backupPath = "$backupRoot\$backupFolder"

Write-Host "Automatically selected latest backup: $backupFolder"

# LGPO.exe Path (Modify if needed)
$lgpoPath = "C:\Windows\System32\LGPO.exe"
$lgpoBackupPath = "$backupPath\GPO_Backup"

# Restore Group Policy
if (Test-Path $lgpoBackupPath) {
    Write-Host "Restoring Group Policy settings..."
    & $lgpoPath /g "$lgpoBackupPath"
    gpupdate /force
} else {
    Write-Host "GPO backup folder not found! Skipping Group Policy restore." -ForegroundColor Yellow
}

# Restore Registry with SYSTEM Privileges
Write-Host "Restoring Registry..."

$regBackupFiles = @(
    "$backupPath\HKLM_Backup.reg"
)

foreach ($file in $regBackupFiles) {
    if (Test-Path $file) {
        Write-Host "Importing: $file"

        # Run reg import with SYSTEM privileges to avoid permission issues
        $command = "reg import `"$file`""
        Start-Process -FilePath "cmd.exe" -ArgumentList "/c $command" -Verb RunAs -Wait

        if ($LASTEXITCODE -eq 0) {
            Write-Host "Successfully restored: $file" -ForegroundColor Green
        } else {
            Write-Host "ERROR: Failed to restore: $file" -ForegroundColor Red
        }
    } else {
        Write-Host "Registry backup file missing: $file" -ForegroundColor Yellow
    }
}

Write-Host "Restore completed successfully!"
Write-Host "Please restart your system for changes to take full effect."