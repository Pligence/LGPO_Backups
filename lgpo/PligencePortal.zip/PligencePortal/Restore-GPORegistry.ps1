# How to use
 
# Environment creation guide :  please place the "psexec.exe" in the same directory where you script is placed
 
# run this command on power shell ===>> replace the path with you script actuall path.
 
#psexec -i -s powershell.exe -ExecutionPolicy Bypass -File "C:\Path\To\Restore-GPORegistry.ps1"
 
# once you run this command this will up with a new powershell window [this line is for when we run this manuallu other wise we will use it with window style 'None' or silently]
# then this new pwer shell windows show the available backups to you then you need to enter the timestamp for the desried backup whihc needs to be restore.
 
 
# Ensure script is running as Administrator
if (-Not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Host "Please run this script as an Administrator!" -ForegroundColor Red
    exit
}
 
# Prompt user for backup folder selection
$backupRoot = "C:\GPO_Backups"
Write-Host "Available backup folders:"
Get-ChildItem -Path $backupRoot -Directory | ForEach-Object { Write-Host $_.Name }
 
$backupFolder = Read-Host "Enter the timestamp folder name to restore (e.g., 20250220-143505)"
$backupPath = "$backupRoot\$backupFolder"
 
if (-Not (Test-Path $backupPath)) {
    Write-Host "Backup folder does not exist! Exiting..." -ForegroundColor Red
    exit
}
 
# LGPO.exe Path (Modify if needed)
$lgpoPath = "C:\Windows\System32\LGPO.exe"
$lgpoBackupPath = "$backupPath\GPO_Backup"
 
# Restore Group Policy
if (Test-Path $lgpoBackupPath) {
    Write-Host "Restoring Group Policy settings..."
    & $lgpoPath /g "$lgpoBackupPath"
    gpupdate /force
} else {
    Write-Host "GPO backup folder not found! Skipping Group Policy restore." -ForegroundColor Yellow
}
 
# Restore Registry with SYSTEM Privileges
Write-Host "Restoring Registry..."
 
$regBackupFiles = @(
    "$backupPath\HKLM_Backup.reg"
)
 
foreach ($file in $regBackupFiles) {
    if (Test-Path $file) {
        Write-Host "Importing: $file"
 
        # Run reg import with SYSTEM privileges to avoid permission issues
        $command = "reg import `"$file`""
        Start-Process -FilePath "cmd.exe" -ArgumentList "/c $command" -Verb RunAs -Wait
 
        if ($LASTEXITCODE -eq 0) {
            Write-Host "Successfully restored: $file" -ForegroundColor Green
        } else {
            Write-Host "ERROR: Failed to restore: $file" -ForegroundColor Red
        }
    } else {
        Write-Host "Registry backup file missing: $file" -ForegroundColor Yellow
    }
}
 
Write-Host "Restore completed successfully!"
Write-Host "Please restart your system for changes to take full effect."
 
 
 