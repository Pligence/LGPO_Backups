param (
    [Parameter(Mandatory=$true)]
    [int]$DelayInSeconds
)



# Function to check if running in user interactive mode
function Test-UserInteractive {
    return [Environment]::UserInteractive
}



# Function to check administrative privileges
function Is-Administrator {
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}



# Simple logging function that doesn't rely on Event Log
function Write-LogMessage {
    param (
        [string]$Message,
        [string]$Type = "INFO"
    )

    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logMessage = "[$timestamp] [$Type] $Message"

    # Write to a file in a location the service can access
    $logPath = "C:\Logs\RestartService.log"

    # Ensure directory exists
    $logDir = Split-Path -Path $logPath -Parent
    if (-not (Test-Path -Path $logDir)) {
        New-Item -ItemType Directory -Path $logDir -Force | Out-Null
    }

    Add-Content -Path $logPath -Value $logMessage
}



# Function to restart the system forcefully
function Restart-SystemForcefully {
    param (
        [int]$delayInSeconds = $DelayInSeconds
    )

    try {
        Write-LogMessage -Message "Attempting to restart system in $delayInSeconds seconds"

        # Try multiple restart methods

        # Method 1: Direct call to shutdown.exe with full path
        $shutdownPath = "$env:SystemRoot\System32\shutdown.exe"
        Write-LogMessage -Message "Executing: $shutdownPath /r /f /t $delayInSeconds /c 'System will restart in $delayInSeconds seconds'"

& $shutdownPath /r /f /t $delayInSeconds /c "System will restart in $delayInSeconds seconds"

        # If we're still running after 2 seconds, try another method
        Start-Sleep -Seconds 2

        # Method 2: Try using Start-Process for better process isolation
        Write-LogMessage -Message "Trying alternate method with Start-Process"
        Start-Process -FilePath $shutdownPath -ArgumentList "/r", "/f", "/t", "$delayInSeconds", "/c", "System will restart in $delayInSeconds seconds" -NoNewWindow

        # Method 3: Last resort - try using WMI
        Start-Sleep -Seconds 2
        Write-LogMessage -Message "Trying WMI restart method as last resort"
        (Get-WmiObject -Class Win32_OperatingSystem).Win32Shutdown(6)

        Write-LogMessage -Message "Restart commands executed successfully"
    }
    catch {
        Write-LogMessage -Message "Error restarting system: $_" -Type "ERROR"
        throw $_
    }
}



# Check if we have admin rights before proceeding
if (-not (Is-Administrator)) {
    Write-LogMessage -Message "Script requires administrative privileges to restart the system" -Type "ERROR"
    throw "This script requires administrative privileges to restart the system."
}



# Attempt the restart
Write-LogMessage -Message "Starting system restart process with $DelayInSeconds second delay"
Restart-SystemForcefully -delayInSeconds $DelayInSeconds
